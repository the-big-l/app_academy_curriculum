



// Write your own myBind(context) method. Add it to Function.prototype.
