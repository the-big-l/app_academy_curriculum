
function myEach(arr, cb) {

}

Array.prototype.myEach = function(cb) => {

};

function myMap() {

}

Array.prototype.myMap = function(cb) {

};

// As the exercise describes, start the accumulator variable with the
// first value. Iterate through the rest.

function myInject() {

}

Array.prototype.myInject = function() {

}
