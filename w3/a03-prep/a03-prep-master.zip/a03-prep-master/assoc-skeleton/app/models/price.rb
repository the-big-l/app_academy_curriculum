class Price < ActiveRecord::Base
end
