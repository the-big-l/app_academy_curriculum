class BoardMembership < ActiveRecord::Base
end
