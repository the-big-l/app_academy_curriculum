//////// Recursion ////////

//You have array of integers. Write a recursive solution to find the
//sum of the integers.

function sumRecur (array) {

}

//You have array of integers. Write a recursive solution to determine
//whether or not the array contains a specific value.

function includes (array, target) {

}

// You have an unsorted array of integers. Write a recursive solution
// to count the number of occurrences of a specific value.

function numOccur (array, target) {

}

//You have array of integers. Write a recursive solution to determine
// whether or not two adjacent elements of the array add to 12.

function addToTwelve (array) {

}

//You have array of integers. Write a recursive solution to determine
// if the array is sorted.

function sorted (array) {

}

//Write a recursive function to reverse a string. Don't use any
// built-in //reverse methods!

function reverse (string) {

}

// Write a recursive method that returns the first "num" factorial numbers.
function digitalRoot (num) {

}

// Write a recursive method that returns an array of first n number of factorials
function factorialsRec (num) {

}

// Write a recursive method that returns an array of numbers between min and max
function range (min, max) {

}

// Write a recursive method that returns the sum of all elements in an array
function sum (nums) {

}

// Write a function sumTo(n) that uses recursion to calculate the sum from
// 1 to n (inclusive of n).
function sumTo(n) {

}

// Write a function add_numbers(nums) that takes in an array of Fixnums and
// returns the sum of those numbers. Write this method recursively.

function addNums(nums) {

}

// Write a recursive method that exponentiates base ** power without using the ** method
function exp (base, power) {

}

// Write a recursive method that returns the first n number of fibonacci numbers in an array
function fibsRec (n) {

}

// Implement a method that finds the sum of the first n
// fibonacci numbers recursively. Assume n > 0
function fibsSum(n) {

}

// Let's write a method that will solve Gamma Function recursively. The Gamma
// Function is defined Γ(n) = (n-1)!.

function gammaFnc(n) {

}

// Write a recursive method subsets that will return all subsets of an array.
function subsets () {

}

// Write a recursive method that returns all of the permutations of an array
function permutations (array) {

}

// Write a recursive method that returns an array of the best change given a target amouunt
function makeChange (target, coins = [25, 10, 5, 1]){

}

// Write a recursive method that returns the sum of the first n even numbers
function firstEvenNumbersSum (n) {

}
