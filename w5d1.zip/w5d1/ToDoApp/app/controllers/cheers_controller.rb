class CheersController < ApplicationController
end
