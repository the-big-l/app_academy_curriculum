require 'rails_helper'

RSpec.describe CheersController, type: :controller do

end
